# robe-pydisbot
A Roblox Bedwars Bot!


The main premise of the bot is to be the main bot of the DXP Clan Server.

Robe will focus on managing Clan Wars info, Economy, Music, and some random Fun commands.
